# 🏆 Project Olympus — Content Ideas
*Auto-generated: June 22, 2026 23:10 UTC · Phase: Group Stage · 41 matches played*

---

## 📈 Biggest Win Probability Movers
*Compare live model vs pre-tournament prediction*

### 🚀 Biggest Risers
- 🇦🇷 **Argentina**: 4.4% → 6.75% (↑ +2.4%)
- 🇺🇸 **USA**: 1.5% → 2.76% (↑ +1.3%)
- 🇳🇱 **Netherlands**: 1.6% → 2.4% (↑ +0.8%)
- 🇯🇵 **Japan**: 1.8% → 2.38% (↑ +0.6%)
- 🇳🇴 **Norway**: 2.1% → 2.67% (↑ +0.6%)

### 📉 Biggest Fallers
- 🇵🇹 **Portugal**: 14.9% → 11.75% (↓ -3.1%)
- 🇩🇪 **Germany**: 10.9% → 8.36% (↓ -2.5%)
- 🇪🇸 **Spain**: 19.0% → 17.67% (↓ -1.3%)
- 🇫🇷 **France**: 11.8% → 11.25% (↓ -0.6%)
- 🇭🇷 **Croatia**: 3.0% → 2.62% (↓ -0.4%)

## 🥇 Current Top 5 to Win the World Cup
*Live model after real match results*

1. 🇪🇸 **Spain** — 17.67% to win · 43.37% to reach final · 56.57% semifinal
2. 🏴󠁧󠁢󠁥󠁮󠁧󠁿 **England** — 14.73% to win · 42.38% to reach final · 64.73% semifinal
3. 🇵🇹 **Portugal** — 11.75% to win · 37.15% to reach final · 55.37% semifinal
4. 🇫🇷 **France** — 11.25% to win · 31.16% to reach final · 46.11% semifinal
5. 🇩🇪 **Germany** — 8.36% to win · 27.56% to reach final · 40.14% semifinal

## 🎯 Model Prediction Accuracy

- **Correct predictions:** 17/30 matches (56.7%)
- **Upsets called wrong:** 13

### 😱 Biggest Upsets (model got wrong)
- 🇪🇸 Spain 0–0 Cape Verde 🇨🇻 · Model only gave this outcome 1.9% chance
- 🇵🇹 Portugal 1–1 DR Congo 🇨🇩 · Model only gave this outcome 13.0% chance
- 🇮🇷 Iran 2–2 New Zealand 🇳🇿 · Model only gave this outcome 18.9% chance
- 🇧🇪 Belgium 0–0 Iran 🇮🇷 · Model only gave this outcome 20.0% chance
- 🇺🇾 Uruguay 2–2 Cape Verde 🇨🇻 · Model only gave this outcome 22.7% chance

## 💥 Over & Underperformers vs Model Expectations
*form_nudge = score adjustment based on actual vs predicted goals*

### ⬆️ Overperforming (better than expected)
- 🇨🇦 **Canada**: +2.49 pts after 2 games
- 🇨🇻 **Cape Verde**: +1.84 pts after 2 games
- 🇳🇱 **Netherlands**: +1.53 pts after 2 games
- 🇨🇩 **DR Congo**: +1.33 pts after 1 game
- 🇦🇷 **Argentina**: +1.29 pts after 2 games

### ⬇️ Underperforming (worse than expected)
- 🇪🇸 **Spain**: -1.74 pts after 2 games
- 🇵🇹 **Portugal**: -1.63 pts after 1 game
- 🇹🇳 **Tunisia**: -1.53 pts after 2 games
- 🇹🇷 **Türkiye**: -1.51 pts after 2 games
- 🇶🇦 **Qatar**: -1.46 pts after 2 games

## ⚽ Golden Boot Race

1. 🇦🇷 **L. Messi** — 6 goals, 0 assists
2. 🇩🇪 **D. Undav** — 3 goals, 2 assists
3. 🇨🇦 **J. David** — 3 goals, 0 assists
4. 🇫🇷 **Kylian Mbappé** — 3 goals, 0 assists
5. 🇧🇷 **Vinícius Júnior** — 2 goals, 1 assist
6. 🇳🇱 **C. Summerville** — 2 goals, 1 assist
7. 🇪🇸 **Mikel Oyarzabal** — 2 goals, 1 assist
8. 🇺🇾 **M. Araújo** — 2 goals, 1 assist
9. 🇯🇵 **A. Ueda** — 2 goals, 1 assist
10. 🇳🇱 **C. Gakpo** — 2 goals, 1 assist

## 📊 Group Stage Snapshot

**Group A**
  → 🇲🇽 Mexico: 6pts · GD +3 · 2P
  → 🇰🇷 South Korea: 3pts · GD +0 · 2P
     🇨🇿 Czechia: 1pts · GD -1 · 2P
     🇿🇦 South Africa: 1pts · GD -2 · 2P

**Group B**
  → 🇨🇦 Canada: 4pts · GD +6 · 2P
  → 🇨🇭 Switzerland: 4pts · GD +3 · 2P
     🇧🇦 Bosnia & Herzegovina: 1pts · GD -3 · 2P
     🇶🇦 Qatar: 1pts · GD -6 · 2P

**Group C**
  → 🇧🇷 Brazil: 4pts · GD +3 · 2P
  → 🇲🇦 Morocco: 4pts · GD +1 · 2P
     🏴󠁧󠁢󠁳󠁣󠁴󠁿 Scotland: 3pts · GD +0 · 2P
     🇭🇹 Haiti: 0pts · GD -4 · 2P

**Group D**
  → 🇺🇸 USA: 6pts · GD +5 · 2P
  → 🇦🇺 Australia: 3pts · GD +0 · 2P
     🇵🇾 Paraguay: 3pts · GD -2 · 2P
     🇹🇷 Türkiye: 0pts · GD -3 · 2P

**Group E**
  → 🇩🇪 Germany: 6pts · GD +7 · 2P
  → 🇨🇮 Ivory Coast: 3pts · GD +0 · 2P
     🇪🇨 Ecuador: 1pts · GD -1 · 2P
     🇨🇼 Curaçao: 1pts · GD -6 · 2P

**Group F**
  → 🇳🇱 Netherlands: 4pts · GD +4 · 2P
  → 🇯🇵 Japan: 4pts · GD +4 · 2P
     🇸🇪 Sweden: 3pts · GD +0 · 2P
     🇹🇳 Tunisia: 0pts · GD -8 · 2P

**Group G**
  → 🇪🇬 Egypt: 4pts · GD +2 · 2P
  → 🇮🇷 Iran: 2pts · GD +0 · 2P
     🇧🇪 Belgium: 2pts · GD +0 · 2P
     🇳🇿 New Zealand: 1pts · GD -2 · 2P

**Group H**
  → 🇪🇸 Spain: 4pts · GD +4 · 2P
  → 🇺🇾 Uruguay: 2pts · GD +0 · 2P
     🇨🇻 Cape Verde: 2pts · GD +0 · 2P
     🇸🇦 Saudi Arabia: 1pts · GD -4 · 2P

**Group I**
  → 🇳🇴 Norway: 3pts · GD +3 · 1P
  → 🇫🇷 France: 3pts · GD +2 · 1P
     🇸🇳 Senegal: 0pts · GD -2 · 1P
     🇮🇶 Iraq: 0pts · GD -3 · 1P

**Group J**
  → 🇦🇷 Argentina: 6pts · GD +5 · 2P
  → 🇦🇹 Austria: 3pts · GD +0 · 2P
     🇯🇴 Jordan: 0pts · GD -2 · 1P
     🇩🇿 Algeria: 0pts · GD -3 · 1P

**Group K**
  → 🇨🇴 Colombia: 3pts · GD +2 · 1P
  → 🇵🇹 Portugal: 1pts · GD +0 · 1P
     🇨🇩 DR Congo: 1pts · GD +0 · 1P
     🇺🇿 Uzbekistan: 0pts · GD -2 · 1P

**Group L**
  → 🏴󠁧󠁢󠁥󠁮󠁧󠁿 England: 3pts · GD +2 · 1P
  → 🇬🇭 Ghana: 3pts · GD +1 · 1P
     🇵🇦 Panama: 0pts · GD -1 · 1P
     🇭🇷 Croatia: 0pts · GD -2 · 1P

---

## ✍️ Ready-to-Post Caption Ideas

### Caption 1 — Biggest Riser
```
🇦🇷 Argentina are the biggest movers in our World Cup model.

Pre-tournament win probability: 4.4%
After 41 matches: 6.75%

That's a +2.4% swing based on real match data.

Our model updates after every game using Poisson simulation
& Bayesian score adjustment. 10,000 simulations per update.

#WC2026 #WorldCup2026 #Football #DataScience #ProjectOlympus
```

### Caption 2 — Model Accuracy
```
📊 41 matches played at WC2026.
Our model predicted the correct outcome in 17/30 (56.7%).

Biggest miss: 🇪🇸 Spain 0–0 Cape Verde 🇨🇻
We only gave that result a 1.9% chance.

That's football. The model learns and adapts after every game.

#WC2026 #WorldCup #FootballData #MachineLearning #ProjectOlympus
```

### Caption 3 — Golden Boot
```
⚽ Golden Boot race at WC2026 — matchday 41 update

1. 🇦🇷 L. Messi — 6G 0A
2. 🇩🇪 D. Undav — 3G 2A
3. 🇨🇦 J. David — 3G 0A
4. 🇫🇷 Kylian Mbappé — 3G 0A
5. 🇧🇷 Vinícius Júnior — 2G 1A

#WC2026 #WorldCup2026 #GoldenBoot #Football #ProjectOlympus
```
